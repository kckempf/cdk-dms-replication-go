import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
/**
 * Returns the account-level `dms-vpc-role` IAM role construct, creating it
 * once per stack. DMS requires this exact role name before it can place
 * replication instances or serverless configs inside a VPC.
 *
 * Safe to call from multiple stacks in the same account — if the role already
 * exists, the underlying SDK call succeeds silently.
 */
export declare function ensureDmsVpcRole(stack: cdk.Stack): Construct;
/**
 * Returns the account-level `dms-cloudwatch-logs-role` IAM role construct,
 * creating it once per stack. DMS requires this exact role name to publish
 * task logs to CloudWatch Logs.
 *
 * Safe to call from multiple stacks in the same account — if the role already
 * exists, the underlying SDK call succeeds silently.
 */
export declare function ensureDmsCloudWatchRole(stack: cdk.Stack): Construct;
