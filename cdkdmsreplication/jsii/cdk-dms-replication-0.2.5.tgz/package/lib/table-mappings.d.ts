/**
 * Table mappings define which schemas/tables DMS migrates and how they are
 * transformed. This builder produces the JSON string that DMS expects for
 * the `tableMappings` property of a replication task.
 *
 * @see https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Tasks.CustomizingTasks.TableMapping.html
 */
/** Whether the rule selects or excludes objects. */
export declare enum SelectionAction {
    INCLUDE = "include",
    EXCLUDE = "exclude",
    EXPLICIT = "explicit"
}
/** Table-level transformation actions. */
export declare enum TransformationAction {
    /** Convert the name to lowercase. */
    CONVERT_LOWERCASE = "convert-lowercase",
    /** Convert the name to uppercase. */
    CONVERT_UPPERCASE = "convert-uppercase",
    /** Add a prefix to the name. */
    ADD_PREFIX = "add-prefix",
    /** Remove a prefix from the name. */
    REMOVE_PREFIX = "remove-prefix",
    /** Add a suffix to the name. */
    ADD_SUFFIX = "add-suffix",
    /** Remove a suffix from the name. */
    REMOVE_SUFFIX = "remove-suffix",
    /** Rename the object. */
    RENAME = "rename",
    /** Remove the column. */
    REMOVE_COLUMN = "remove-column",
    /** Add a column. */
    ADD_COLUMN = "add-column",
    /** Include the column. */
    INCLUDE_COLUMN = "include-column"
}
/** The object type a rule targets. */
export declare enum RuleObjectLocator {
    SCHEMA = "schema",
    TABLE = "table",
    COLUMN = "column",
    TABLE_TABLESPACE = "table-tablespace",
    INDEX_TABLESPACE = "index-tablespace"
}
/** DynamoDB attribute sub-type for object-mapping rules. */
export declare enum DynamoDbAttributeSubType {
    STRING = "string",
    NUMBER = "number",
    BINARY = "binary"
}
/** Data type for added columns. */
export declare enum ColumnDataType {
    STRING = "string",
    INT4 = "int4",
    INT8 = "int8",
    FLOAT4 = "float4",
    FLOAT8 = "float8",
    NUMERIC = "numeric",
    DATETIME = "datetime",
    BYTES = "bytes",
    BLOB = "blob"
}
/** A column added via an ADD_COLUMN transformation. */
export interface AddColumnDefinition {
    /** Name of the new column. */
    readonly columnName: string;
    /** Data type of the new column. */
    readonly columnType: ColumnDataType;
    /** Character length for string columns. */
    readonly columnLength?: number;
    /** Precision for numeric columns. */
    readonly columnPrecision?: number;
    /** Scale for numeric columns. */
    readonly columnScale?: number;
    /**
     * Constant string value to populate the column with. Emitted as a
     * single-quoted DMS expression literal — use only for string column types.
     * For numeric or datetime types, use `expression` with an unquoted literal
     * (e.g. `expression: '42'`).
     * Exactly one of `columnValue` or `expression` must be set.
     */
    readonly columnValue?: string;
    /**
     * DMS expression to populate the column (e.g. `$timestamp`,
     * `'ENTITY#' || $id`, or an unquoted numeric literal like `42`).
     * Exactly one of `columnValue` or `expression` must be set.
     */
    readonly expression?: string;
}
/** Object locator identifying the schema, table, and optional column a rule targets. */
export interface RuleObjectLocatorValue {
    readonly schemaName: string;
    readonly tableName?: string;
    readonly columnName?: string;
}
/**
 * Mapping from a source column (or DMS expression) to a DynamoDB partition or
 * sort key attribute. Exactly one of `sourceColumn` or `value` must be set.
 */
export interface DynamoDbKeyMapping {
    /**
     * Name of a single column on the relational source. The builder wraps this
     * in the DMS expression `${sourceColumn}`. Mutually exclusive with `value`.
     */
    readonly sourceColumn?: string;
    /**
     * Raw DMS value expression, used verbatim. Use this for composite keys or
     * other expressions like `'CUSTOMER#${customer_id}'`. Mutually exclusive
     * with `sourceColumn`.
     */
    readonly value?: string;
    /** Name of the partition/sort key attribute on the DynamoDB target item. */
    readonly targetAttributeName: string;
    /** DynamoDB attribute sub-type (`string`, `number`, or `binary`). */
    readonly attributeSubType: DynamoDbAttributeSubType;
}
/**
 * Mapping from a source column (or DMS expression) to a non-key attribute on
 * the DynamoDB target. Exactly one of `sourceColumn` or `value` must be set.
 * Source columns not listed in `attributeMappings` or `excludeColumns` pass
 * through with the source column name.
 */
export interface DynamoDbAttributeMapping {
    /**
     * Name of a single column on the relational source. The builder wraps this
     * in the DMS expression `${sourceColumn}`. Mutually exclusive with `value`.
     */
    readonly sourceColumn?: string;
    /**
     * Raw DMS value expression, used verbatim. Use this for composite values or
     * other expressions like `'STATUS#${status}'`. Mutually exclusive with
     * `sourceColumn`.
     */
    readonly value?: string;
    /** Name of the attribute on the DynamoDB target item. */
    readonly targetAttributeName: string;
    /** DynamoDB attribute sub-type (`string`, `number`, or `binary`). */
    readonly attributeSubType: DynamoDbAttributeSubType;
}
/** Options for `TableMappings.mapToDynamoDb`. */
export interface DynamoDbObjectMappingOptions {
    /** Name of the target DynamoDB table. */
    readonly targetTableName: string;
    /** Mapping for the DynamoDB partition (hash) key. Required. */
    readonly partitionKey: DynamoDbKeyMapping;
    /** Mapping for the DynamoDB sort (range) key. Optional. */
    readonly sortKey?: DynamoDbKeyMapping;
    /** Source columns to exclude from the migrated item. */
    readonly excludeColumns?: string[];
    /**
     * Additional column-to-attribute mappings. Use this to rename non-key
     * columns or change their DynamoDB sub-type. Columns not listed here pass
     * through with the source column name.
     */
    readonly attributeMappings?: DynamoDbAttributeMapping[];
}
/** Represents a single, fully built rule in the table-mappings JSON. */
export interface TableMappingRule {
    readonly ruleType: string;
    readonly ruleId: string;
    readonly ruleName: string;
    readonly objectLocator: RuleObjectLocatorValue;
    readonly ruleAction: string;
    readonly value?: string;
    readonly oldValue?: string;
}
/**
 * Fluent builder for DMS table mappings.
 *
 * @example
 * const mappings = new TableMappings()
 *   .includeSchema('public')
 *   .includeTable('public', 'orders')
 *   .excludeTable('public', 'audit_log')
 *   .renameSchema('public', 'prod')
 *   .toLowerCaseTable('public', '%')
 *   .toJson();
 */
export declare class TableMappings {
    private readonly rules;
    private nextId;
    /**
     * Include all tables in a schema.
     * Use `%` as a wildcard for `schemaName` to include all schemas.
     */
    includeSchema(schemaName: string): TableMappings;
    /** Exclude all tables in a schema. */
    excludeSchema(schemaName: string): TableMappings;
    /**
     * Include a specific table (or a wildcard pattern) within a schema.
     * Use `%` for `tableName` to match all tables in the schema.
     */
    includeTable(schemaName: string, tableName: string): TableMappings;
    /** Exclude a specific table (or wildcard) within a schema. */
    excludeTable(schemaName: string, tableName: string): TableMappings;
    /**
     * Explicitly include a single table. Unlike `include`, `explicit` means DMS
     * only migrates this one table regardless of other `include` rules.
     */
    explicitTable(schemaName: string, tableName: string): TableMappings;
    private addSelectionRule;
    /** Rename a schema. */
    renameSchema(schemaName: string, newName: string): TableMappings;
    /** Convert all schema names to lowercase. */
    toLowerCaseSchema(schemaName: string): TableMappings;
    /** Convert all schema names to uppercase. */
    toUpperCaseSchema(schemaName: string): TableMappings;
    /** Add a prefix to schema names. */
    addPrefixToSchema(schemaName: string, prefix: string): TableMappings;
    /** Add a suffix to schema names. */
    addSuffixToSchema(schemaName: string, suffix: string): TableMappings;
    /** Rename a table. */
    renameTable(schemaName: string, tableName: string, newName: string): TableMappings;
    /** Convert matching table names to lowercase. Use `%` to match all tables. */
    toLowerCaseTable(schemaName: string, tableName: string): TableMappings;
    /** Convert matching table names to uppercase. */
    toUpperCaseTable(schemaName: string, tableName: string): TableMappings;
    /** Add a prefix to table names. */
    addPrefixToTable(schemaName: string, tableName: string, prefix: string): TableMappings;
    /** Add a suffix to table names. */
    addSuffixToTable(schemaName: string, tableName: string, suffix: string): TableMappings;
    /** Rename a column in a table. */
    renameColumn(schemaName: string, tableName: string, columnName: string, newName: string): TableMappings;
    /** Convert matching column names to lowercase. */
    toLowerCaseColumn(schemaName: string, tableName: string, columnName: string): TableMappings;
    /** Convert matching column names to uppercase. */
    toUpperCaseColumn(schemaName: string, tableName: string, columnName: string): TableMappings;
    /** Remove a column from a table. */
    removeColumn(schemaName: string, tableName: string, columnName: string): TableMappings;
    /**
     * Add a new column to a table.
     *
     * @example
     * mappings.addColumn('public', 'orders', {
     *   columnName: 'migration_ts',
     *   columnType: ColumnDataType.DATETIME,
     *   expression: '$timestamp',
     * });
     */
    addColumn(schemaName: string, tableName: string, column: AddColumnDefinition): TableMappings;
    private buildDataType;
    /**
     * Map a relational source table to a DynamoDB target table.
     *
     * Emits a DMS `object-mapping` rule with `rule-action: map-record-to-record`.
     * DMS requires this rule type when the target endpoint is DynamoDB; the
     * partition key (and optional sort key) tell DMS how to build the item key
     * from source columns.
     *
     * Source columns not listed in `attributeMappings` or `excludeColumns` are
     * migrated with the source column name as the attribute name.
     *
     * For each key or attribute mapping, set either `sourceColumn` (a single
     * column wrapped as `${col}`) or `value` (a raw DMS expression, e.g.
     * `'CUSTOMER#${customer_id}'` for composite keys). Exactly one is required.
     *
     * Calling this method twice with the same `schemaName`/`tableName` emits two
     * separate rules; DMS will reject duplicate object-mapping rules at deploy
     * time. Call it once per source table.
     *
     * @example
     * const mappings = new TableMappings()
     *   .includeTable('public', 'orders')
     *   .mapToDynamoDb('public', 'orders', {
     *     targetTableName: 'Orders',
     *     // Composite partition key from a literal prefix + source column:
     *     partitionKey: {
     *       value: 'CUSTOMER#${customer_id}',
     *       targetAttributeName: 'PK',
     *       attributeSubType: DynamoDbAttributeSubType.STRING,
     *     },
     *     // Bare source column for the sort key:
     *     sortKey: {
     *       sourceColumn: 'created_at',
     *       targetAttributeName: 'CreatedAt',
     *       attributeSubType: DynamoDbAttributeSubType.STRING,
     *     },
     *     excludeColumns: ['internal_flag'],
     *     attributeMappings: [
     *       {
     *         sourceColumn: 'customer_id',
     *         targetAttributeName: 'CustomerId',
     *         attributeSubType: DynamoDbAttributeSubType.STRING,
     *       },
     *     ],
     *   })
     *   .toJson();
     */
    mapToDynamoDb(schemaName: string, tableName: string, options: DynamoDbObjectMappingOptions): TableMappings;
    private checkNotExcluded;
    private buildAttributeMapping;
    private addTransformationRule;
    /**
     * Serialise the accumulated rules to the JSON string expected by DMS.
     * Passes the result directly to `replicationTaskSettings` or
     * `DmsReplicationTask.tableMappings`.
     */
    toJson(): string;
}
