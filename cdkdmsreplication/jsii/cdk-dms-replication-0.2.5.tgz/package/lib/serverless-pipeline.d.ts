import * as cdk from 'aws-cdk-lib';
import * as dms from 'aws-cdk-lib/aws-dms';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import { IDmsEndpoint } from './endpoint';
import { MigrationType } from './enums';
import { SourceEndpointOptions, TargetEndpointOptions } from './migration-pipeline';
/** Props for {@link DmsServerlessPipeline}. */
export interface DmsServerlessPipelineProps {
    /**
     * VPC in which to place the serverless replication config.
     * The config is placed in private subnets.
     */
    readonly vpc: ec2.IVpc;
    /**
     * Subnet selection for the replication subnet group.
     * @default private subnets with egress
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * Security groups to attach to the serverless replication config.
     * A new security group is created if none are provided.
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * Maximum number of DMS Capacity Units (DCUs) the serverless replication may
     * scale up to.
     *
     * Valid values: 1, 2, 4, 8, 16, 32, 64, 128, 192, 256, 384.
     */
    readonly maxCapacityUnits: number;
    /**
     * Minimum number of DCUs DMS will provision at start-up.
     * @default DMS auto-determines based on workload
     */
    readonly minCapacityUnits?: number;
    /**
     * Whether the serverless replication is Multi-AZ.
     * @default false
     */
    readonly multiAz?: boolean;
    /**
     * Preferred maintenance window, e.g. "sun:04:00-sun:04:30".
     */
    readonly preferredMaintenanceWindow?: string;
    /**
     * KMS key used to encrypt replication storage at rest.
     * A new key is created if not provided.
     */
    readonly kmsKey?: kms.IKey;
    /**
     * Source endpoint configuration.
     * Provide this OR `existingSourceEndpoint` — not both.
     */
    readonly sourceEndpoint?: SourceEndpointOptions;
    /**
     * An existing {@link IDmsEndpoint} to use as the source.
     * Provide this OR `sourceEndpoint` — not both.
     */
    readonly existingSourceEndpoint?: IDmsEndpoint;
    /**
     * Target endpoint configuration.
     * Provide this OR `existingTargetEndpoint` — not both.
     */
    readonly targetEndpoint?: TargetEndpointOptions;
    /**
     * An existing {@link IDmsEndpoint} to use as the target.
     * Provide this OR `targetEndpoint` — not both.
     */
    readonly existingTargetEndpoint?: IDmsEndpoint;
    /** The type of migration to perform. */
    readonly migrationType: MigrationType;
    /**
     * Table mappings JSON string.
     * Use {@link TableMappings} to build this.
     * Defaults to "include all tables in all schemas" if not provided.
     */
    readonly tableMappings?: string;
    /**
     * Replication settings JSON string (equivalent to task settings for classic DMS).
     * Use {@link TaskSettings} to build this.
     * Sensible defaults are applied by DMS if not provided.
     *
     * @remarks DMS Serverless does not support setting CDC start/stop positions
     * via CloudFormation. To start replication from a specific LSN or timestamp
     * after the replication config has been created, call the
     * `StartReplication` API with `StartReplicationTaskType` set to
     * `start-replication` and supply `CdcStartPosition` or `CdcStartTime`.
     */
    readonly taskSettings?: string;
    /**
     * Whether to create a CloudWatch log group for the replication config.
     * @default true
     */
    readonly enableCloudWatchLogs?: boolean;
    /**
     * Retention period for the CloudWatch log group.
     * @default logs.RetentionDays.ONE_MONTH
     */
    readonly logRetention?: logs.RetentionDays;
    /**
     * Whether to create the two account-level DMS service roles (`dms-vpc-role`
     * and `dms-cloudwatch-logs-role`) required by DMS.
     *
     * When `true`, the roles are created idempotently via a custom resource: if
     * either role already exists in the account (created by another stack or
     * manually), the existing role is silently reused and its trust policy is
     * corrected if necessary. The roles are created with `RemovalPolicy.RETAIN`
     * and are **not** lifecycle-managed by this stack — they will not be deleted
     * when the stack is destroyed. If you require the roles to be
     * lifecycle-managed, create them in a dedicated stack and set this to
     * `false`, then pass cross-stack references as needed.
     *
     * When `false`, the construct expects the roles to already be present and
     * skips creating them. The `dmsVpcRole` and `dmsCloudWatchRole` properties
     * will be `undefined`.
     *
     * @default true
     */
    readonly createDmsServiceRoles?: boolean;
    /**
     * Logical identifier for the replication config resource.
     * @default unique name derived from the construct id
     */
    readonly replicationConfigIdentifier?: string;
    /**
     * Removal policy applied to all resources in the pipeline.
     * @default cdk.RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: cdk.RemovalPolicy;
}
/**
 * An L3 CDK pattern construct that provisions a DMS Serverless replication
 * pipeline:
 *
 * - **Replication config** — backed by `CfnReplicationConfig`; DMS auto-scales
 *   capacity between `minCapacityUnits` and `maxCapacityUnits`.
 * - **Source endpoint** — supports every engine DMS supports.
 * - **Target endpoint** — supports every engine DMS supports.
 * - **Subnet group** — private subnet placement.
 * - **KMS key** — storage encryption at rest (created if not provided).
 * - **Security group** — dedicated group (created if not provided).
 * - **IAM roles** — `dms-vpc-role` and `dms-cloudwatch-logs-role`.
 * - **CloudWatch log group** — (optional) retains replication logs.
 *
 * > **CDC start/stop position limitation**: `CfnReplicationConfig` does not
 * > expose `cdcStartTime` / `cdcStartPosition` / `cdcStopPosition`. To start
 * > from a specific position, call the `StartReplication` API directly after
 * > the config is created (e.g. from a Lambda custom resource or CLI).
 *
 * @example
 * const pipeline = new DmsServerlessPipeline(this, 'ServerlessPipeline', {
 *   vpc,
 *   maxCapacityUnits: 8,
 *   migrationType: MigrationType.FULL_LOAD_AND_CDC,
 *   sourceEndpoint: {
 *     engine: EndpointEngine.MYSQL,
 *     serverName: 'mysql.example.com',
 *     port: 3306,
 *     username: 'dms_user',
 *     password: cdk.SecretValue.secretsManager('mysql-dms-secret'),
 *   },
 *   targetEndpoint: {
 *     engine: EndpointEngine.AURORA_POSTGRESQL,
 *     serverName: cluster.clusterEndpoint.hostname,
 *     port: 5432,
 *     username: 'dms_user',
 *     password: cdk.SecretValue.secretsManager('aurora-dms-secret'),
 *   },
 * });
 */
export declare class DmsServerlessPipeline extends Construct {
    /** The underlying `CfnReplicationConfig` resource. */
    readonly cfnReplicationConfig: dms.CfnReplicationConfig;
    /** The ARN of the replication config. */
    readonly replicationConfigArn: string;
    /** The source endpoint used by this pipeline. */
    readonly source: IDmsEndpoint;
    /** The target endpoint used by this pipeline. */
    readonly target: IDmsEndpoint;
    /** The replication subnet group created for this pipeline. */
    readonly subnetGroup: dms.CfnReplicationSubnetGroup;
    /** The KMS key used for storage encryption. */
    readonly encryptionKey: kms.IKey;
    /** The security group attached to this pipeline. */
    readonly securityGroup: ec2.ISecurityGroup;
    /** CloudWatch log group for the replication config (if enableCloudWatchLogs is true). */
    readonly logGroup?: logs.LogGroup;
    /**
     * Construct wrapping the custom resources that created the `dms-cloudwatch-logs-role`.
     * `undefined` when `createDmsServiceRoles` is `false`.
     */
    readonly dmsCloudWatchRole?: Construct;
    /**
     * Construct wrapping the custom resources that created the `dms-vpc-role`.
     * `undefined` when `createDmsServiceRoles` is `false`.
     */
    readonly dmsVpcRole?: Construct;
    constructor(scope: Construct, id: string, props: DmsServerlessPipelineProps);
    private validateProps;
}
