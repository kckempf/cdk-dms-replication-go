import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as logs from 'aws-cdk-lib/aws-logs';
import { Construct } from 'constructs';
import { DmsEndpointProps, IDmsEndpoint } from './endpoint';
import { MigrationType, ReplicationInstanceClass } from './enums';
import { DmsReplicationInstance } from './replication-instance';
import { DmsReplicationTask } from './replication-task';
/**
 * Properties for the source endpoint of a {@link DmsMigrationPipeline}.
 * Extends {@link DmsEndpointProps} but omits `endpointType` (always SOURCE).
 */
export interface SourceEndpointOptions {
    readonly engine: DmsEndpointProps['engine'];
    readonly endpointIdentifier?: string;
    readonly serverName?: string;
    readonly port?: number;
    readonly username?: string;
    /**
     * Database password. The resolved value is stored as **plaintext** in the
     * CloudFormation template. Prefer `secretsManagerSecretId` in the
     * engine-specific settings for production workloads.
     */
    readonly password?: cdk.SecretValue;
    readonly databaseName?: string;
    readonly extraConnectionAttributes?: string;
    readonly certificateArn?: string;
    readonly sslMode?: string;
    readonly mySqlSettings?: DmsEndpointProps['mySqlSettings'];
    readonly postgreSqlSettings?: DmsEndpointProps['postgreSqlSettings'];
    readonly oracleSettings?: DmsEndpointProps['oracleSettings'];
    readonly sqlServerSettings?: DmsEndpointProps['sqlServerSettings'];
    readonly sapAseSettings?: DmsEndpointProps['sapAseSettings'];
    readonly db2Settings?: DmsEndpointProps['db2Settings'];
    readonly mongoDbSettings?: DmsEndpointProps['mongoDbSettings'];
    readonly s3Settings?: DmsEndpointProps['s3Settings'];
}
/**
 * Properties for the target endpoint of a {@link DmsMigrationPipeline}.
 * Extends {@link DmsEndpointProps} but omits `endpointType` (always TARGET).
 */
export interface TargetEndpointOptions {
    readonly engine: DmsEndpointProps['engine'];
    readonly endpointIdentifier?: string;
    readonly serverName?: string;
    readonly port?: number;
    readonly username?: string;
    /**
     * Database password. The resolved value is stored as **plaintext** in the
     * CloudFormation template. Prefer `secretsManagerSecretId` in the
     * engine-specific settings for production workloads.
     */
    readonly password?: cdk.SecretValue;
    readonly databaseName?: string;
    readonly extraConnectionAttributes?: string;
    readonly certificateArn?: string;
    readonly sslMode?: string;
    readonly mySqlSettings?: DmsEndpointProps['mySqlSettings'];
    readonly postgreSqlSettings?: DmsEndpointProps['postgreSqlSettings'];
    readonly oracleSettings?: DmsEndpointProps['oracleSettings'];
    readonly sqlServerSettings?: DmsEndpointProps['sqlServerSettings'];
    readonly sapAseSettings?: DmsEndpointProps['sapAseSettings'];
    readonly db2Settings?: DmsEndpointProps['db2Settings'];
    readonly mongoDbSettings?: DmsEndpointProps['mongoDbSettings'];
    readonly s3Settings?: DmsEndpointProps['s3Settings'];
    readonly dynamoDbSettings?: DmsEndpointProps['dynamoDbSettings'];
    readonly redshiftSettings?: DmsEndpointProps['redshiftSettings'];
    readonly kinesisSettings?: DmsEndpointProps['kinesisSettings'];
    readonly kafkaSettings?: DmsEndpointProps['kafkaSettings'];
    readonly openSearchSettings?: DmsEndpointProps['openSearchSettings'];
    readonly neptuneSettings?: DmsEndpointProps['neptuneSettings'];
    readonly redisSettings?: DmsEndpointProps['redisSettings'];
}
/** Top-level props for {@link DmsMigrationPipeline}. */
export interface DmsMigrationPipelineProps {
    /**
     * VPC in which to place the replication instance.
     * The instance is placed in private subnets.
     */
    readonly vpc: ec2.IVpc;
    /**
     * Subnet selection for the replication instance.
     * @default private subnets with egress
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * Replication instance class.
     * @default ReplicationInstanceClass.R6I_LARGE
     */
    readonly replicationInstanceClass?: ReplicationInstanceClass;
    /**
     * Allocated storage for the replication instance in GB.
     * @default 100
     */
    readonly allocatedStorage?: number;
    /**
     * Whether the replication instance is Multi-AZ.
     * @default false
     */
    readonly multiAz?: boolean;
    /**
     * Engine version for the replication instance.
     * @default latest version available in the region (chosen by DMS)
     */
    readonly engineVersion?: string;
    /**
     * KMS key for encrypting the replication instance storage at rest.
     * A new key is created if not provided.
     */
    readonly encryptionKey?: kms.IKey;
    /**
     * Source endpoint configuration.
     * Provide this OR `existingSourceEndpoint` — not both.
     */
    readonly sourceEndpoint?: SourceEndpointOptions;
    /**
     * An existing {@link IDmsEndpoint} to use as the source.
     * Provide this OR `sourceEndpoint` — not both.
     */
    readonly existingSourceEndpoint?: IDmsEndpoint;
    /**
     * Target endpoint configuration.
     * Provide this OR `existingTargetEndpoint` — not both.
     */
    readonly targetEndpoint?: TargetEndpointOptions;
    /**
     * An existing {@link IDmsEndpoint} to use as the target.
     * Provide this OR `targetEndpoint` — not both.
     */
    readonly existingTargetEndpoint?: IDmsEndpoint;
    /** The type of migration to perform. */
    readonly migrationType: MigrationType;
    /**
     * Table mappings JSON string.
     * Use {@link TableMappings} to build this.
     * Defaults to "include all tables in all schemas" if not provided.
     */
    readonly tableMappings?: string;
    /**
     * Task settings JSON string.
     * Use {@link TaskSettings} to build this.
     * Sensible defaults are applied if not provided.
     */
    readonly taskSettings?: string;
    /**
     * CDC start time (ISO-8601 string or Unix epoch seconds).
     * Only used when migrationType includes CDC.
     */
    readonly cdcStartTime?: string;
    /**
     * CDC start position (LSN or equivalent).
     * Only used when migrationType includes CDC.
     */
    readonly cdcStartPosition?: string;
    /**
     * CDC stop position.
     * Only used when migrationType includes CDC.
     */
    readonly cdcStopPosition?: string;
    /**
     * Whether to create a CloudWatch log group for the task.
     * @default true
     */
    readonly enableCloudWatchLogs?: boolean;
    /**
     * Retention period for the CloudWatch log group.
     * @default logs.RetentionDays.ONE_MONTH
     */
    readonly logRetention?: logs.RetentionDays;
    /**
     * Whether to create the two account-level DMS service roles (`dms-vpc-role`
     * and `dms-cloudwatch-logs-role`) required by DMS.
     *
     * When `true`, the roles are created idempotently via a custom resource: if
     * either role already exists in the account (created by another stack or
     * manually), the existing role is silently reused and its trust policy is
     * corrected if necessary. The roles are created with `RemovalPolicy.RETAIN`
     * and are **not** lifecycle-managed by this stack — they will not be deleted
     * when the stack is destroyed. If you require the roles to be
     * lifecycle-managed, create them in a dedicated stack and set this to
     * `false`, then pass cross-stack references as needed.
     *
     * When `false`, the construct expects the roles to already be present and
     * skips creating them. The `dmsVpcRole` and `dmsCloudWatchRole` properties
     * will be `undefined`.
     *
     * @default true
     */
    readonly createDmsServiceRoles?: boolean;
    /**
     * Removal policy applied to all resources in the pipeline.
     * @default cdk.RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: cdk.RemovalPolicy;
}
/**
 * An L3 CDK pattern construct that provisions a complete DMS migration pipeline:
 *
 * - **Replication instance** — placed in private subnets with KMS encryption
 *   and a dedicated security group.
 * - **Source endpoint** — supports every engine DMS supports.
 * - **Target endpoint** — supports every engine DMS supports.
 * - **Replication task** — wires the instance, endpoints, table mappings and
 *   task settings together.
 * - **IAM role** — grants DMS permission to write to CloudWatch Logs.
 * - **CloudWatch log group** — (optional) retains task logs.
 *
 * @example
 * // MySQL → Aurora PostgreSQL, full-load-and-CDC
 * const pipeline = new DmsMigrationPipeline(this, 'MigrationPipeline', {
 *   vpc,
 *   migrationType: MigrationType.FULL_LOAD_AND_CDC,
 *   sourceEndpoint: {
 *     engine: EndpointEngine.MYSQL,
 *     serverName: 'mysql.example.com',
 *     port: 3306,
 *     username: 'dms_user',
 *     password: cdk.SecretValue.secretsManager('mysql-dms-secret'),
 *     databaseName: 'mydb',
 *   },
 *   targetEndpoint: {
 *     engine: EndpointEngine.AURORA_POSTGRESQL,
 *     serverName: cluster.clusterEndpoint.hostname,
 *     port: 5432,
 *     username: 'dms_user',
 *     password: cdk.SecretValue.secretsManager('aurora-dms-secret'),
 *     databaseName: 'mydb',
 *   },
 *   tableMappings: new TableMappings().includeSchema('public').toJson(),
 * });
 */
export declare class DmsMigrationPipeline extends Construct {
    /** The replication instance provisioned by this pipeline. */
    readonly replicationInstance: DmsReplicationInstance;
    /** The source endpoint used by this pipeline. */
    readonly source: IDmsEndpoint;
    /** The target endpoint used by this pipeline. */
    readonly target: IDmsEndpoint;
    /** The replication task that drives the migration. */
    readonly replicationTask: DmsReplicationTask;
    /** CloudWatch log group for the task (if enableCloudWatchLogs is true). */
    readonly logGroup?: logs.LogGroup;
    /**
     * Construct wrapping the custom resources that created the `dms-cloudwatch-logs-role`.
     * `undefined` when `createDmsServiceRoles` is `false`.
     */
    readonly dmsCloudWatchRole?: Construct;
    /**
     * Construct wrapping the custom resources that created the `dms-vpc-role`.
     * `undefined` when `createDmsServiceRoles` is `false`.
     */
    readonly dmsVpcRole?: Construct;
    constructor(scope: Construct, id: string, props: DmsMigrationPipelineProps);
    private validateProps;
}
