/**
 * Table mappings define which schemas/tables DMS migrates and how they are
 * transformed. This builder produces the JSON string that DMS expects for
 * the `tableMappings` property of a replication task.
 *
 * @see https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Tasks.CustomizingTasks.TableMapping.html
 */
/** Whether the rule selects or excludes objects. */
export declare enum SelectionAction {
    INCLUDE = "include",
    EXCLUDE = "exclude",
    EXPLICIT = "explicit"
}
/** Table-level transformation actions. */
export declare enum TransformationAction {
    /** Convert the name to lowercase. */
    CONVERT_LOWERCASE = "convert-lowercase",
    /** Convert the name to uppercase. */
    CONVERT_UPPERCASE = "convert-uppercase",
    /** Add a prefix to the name. */
    ADD_PREFIX = "add-prefix",
    /** Remove a prefix from the name. */
    REMOVE_PREFIX = "remove-prefix",
    /** Add a suffix to the name. */
    ADD_SUFFIX = "add-suffix",
    /** Remove a suffix from the name. */
    REMOVE_SUFFIX = "remove-suffix",
    /** Rename the object. */
    RENAME = "rename",
    /** Remove the column. */
    REMOVE_COLUMN = "remove-column",
    /** Add a column. */
    ADD_COLUMN = "add-column",
    /** Include the column. */
    INCLUDE_COLUMN = "include-column"
}
/** The object type a rule targets. */
export declare enum RuleObjectLocator {
    SCHEMA = "schema",
    TABLE = "table",
    COLUMN = "column",
    TABLE_TABLESPACE = "table-tablespace",
    INDEX_TABLESPACE = "index-tablespace"
}
/** Data type for added columns. */
export declare enum ColumnDataType {
    STRING = "string",
    INT4 = "int4",
    INT8 = "int8",
    FLOAT4 = "float4",
    FLOAT8 = "float8",
    NUMERIC = "numeric",
    DATETIME = "datetime",
    BYTES = "bytes",
    BLOB = "blob"
}
/** A column added via an ADD_COLUMN transformation. */
export interface AddColumnDefinition {
    /** Name of the new column. */
    readonly columnName: string;
    /** Data type of the new column. */
    readonly columnType: ColumnDataType;
    /** Character length for string columns. */
    readonly columnLength?: number;
    /** Precision for numeric columns. */
    readonly columnPrecision?: number;
    /** Scale for numeric columns. */
    readonly columnScale?: number;
    /**
     * Constant string value to populate the column with. Emitted as a
     * single-quoted DMS expression literal — use only for string column types.
     * For numeric or datetime types, use `expression` with an unquoted literal
     * (e.g. `expression: '42'`).
     * Exactly one of `columnValue` or `expression` must be set.
     */
    readonly columnValue?: string;
    /**
     * DMS expression to populate the column (e.g. `$timestamp`,
     * `'ENTITY#' || $id`, or an unquoted numeric literal like `42`).
     * Exactly one of `columnValue` or `expression` must be set.
     */
    readonly expression?: string;
}
/** Object locator identifying the schema, table, and optional column a rule targets. */
export interface RuleObjectLocatorValue {
    readonly schemaName: string;
    readonly tableName?: string;
    readonly columnName?: string;
}
/** Represents a single, fully built rule in the table-mappings JSON. */
export interface TableMappingRule {
    readonly ruleType: string;
    readonly ruleId: string;
    readonly ruleName: string;
    readonly objectLocator: RuleObjectLocatorValue;
    readonly ruleAction: string;
    readonly value?: string;
    readonly oldValue?: string;
}
/**
 * Fluent builder for DMS table mappings.
 *
 * @example
 * const mappings = new TableMappings()
 *   .includeSchema('public')
 *   .includeTable('public', 'orders')
 *   .excludeTable('public', 'audit_log')
 *   .renameSchema('public', 'prod')
 *   .toLowerCaseTable('public', '%')
 *   .toJson();
 */
export declare class TableMappings {
    private readonly rules;
    private nextId;
    /**
     * Include all tables in a schema.
     * Use `%` as a wildcard for `schemaName` to include all schemas.
     */
    includeSchema(schemaName: string): TableMappings;
    /** Exclude all tables in a schema. */
    excludeSchema(schemaName: string): TableMappings;
    /**
     * Include a specific table (or a wildcard pattern) within a schema.
     * Use `%` for `tableName` to match all tables in the schema.
     */
    includeTable(schemaName: string, tableName: string): TableMappings;
    /** Exclude a specific table (or wildcard) within a schema. */
    excludeTable(schemaName: string, tableName: string): TableMappings;
    /**
     * Explicitly include a single table. Unlike `include`, `explicit` means DMS
     * only migrates this one table regardless of other `include` rules.
     */
    explicitTable(schemaName: string, tableName: string): TableMappings;
    private addSelectionRule;
    /** Rename a schema. */
    renameSchema(schemaName: string, newName: string): TableMappings;
    /** Convert all schema names to lowercase. */
    toLowerCaseSchema(schemaName: string): TableMappings;
    /** Convert all schema names to uppercase. */
    toUpperCaseSchema(schemaName: string): TableMappings;
    /** Add a prefix to schema names. */
    addPrefixToSchema(schemaName: string, prefix: string): TableMappings;
    /** Add a suffix to schema names. */
    addSuffixToSchema(schemaName: string, suffix: string): TableMappings;
    /** Rename a table. */
    renameTable(schemaName: string, tableName: string, newName: string): TableMappings;
    /** Convert matching table names to lowercase. Use `%` to match all tables. */
    toLowerCaseTable(schemaName: string, tableName: string): TableMappings;
    /** Convert matching table names to uppercase. */
    toUpperCaseTable(schemaName: string, tableName: string): TableMappings;
    /** Add a prefix to table names. */
    addPrefixToTable(schemaName: string, tableName: string, prefix: string): TableMappings;
    /** Add a suffix to table names. */
    addSuffixToTable(schemaName: string, tableName: string, suffix: string): TableMappings;
    /** Rename a column in a table. */
    renameColumn(schemaName: string, tableName: string, columnName: string, newName: string): TableMappings;
    /** Convert matching column names to lowercase. */
    toLowerCaseColumn(schemaName: string, tableName: string, columnName: string): TableMappings;
    /** Convert matching column names to uppercase. */
    toUpperCaseColumn(schemaName: string, tableName: string, columnName: string): TableMappings;
    /** Remove a column from a table. */
    removeColumn(schemaName: string, tableName: string, columnName: string): TableMappings;
    /**
     * Add a new column to a table.
     *
     * @example
     * mappings.addColumn('public', 'orders', {
     *   columnName: 'migration_ts',
     *   columnType: ColumnDataType.DATETIME,
     *   expression: '$timestamp',
     * });
     */
    addColumn(schemaName: string, tableName: string, column: AddColumnDefinition): TableMappings;
    private buildDataType;
    private addTransformationRule;
    /**
     * Serialise the accumulated rules to the JSON string expected by DMS.
     * Passes the result directly to `replicationTaskSettings` or
     * `DmsReplicationTask.tableMappings`.
     */
    toJson(): string;
}
