/**
 * Builder for DMS replication task settings.
 *
 * The DMS task settings JSON controls logging, LOB handling, error handling,
 * full-load tuning, and CDC tuning. This builder exposes the most commonly
 * tuned knobs and produces the JSON string expected by a replication task.
 *
 * @see https://docs.aws.amazon.com/dms/latest/userguide/CHAP_Tasks.CustomizingTasks.TaskSettings.html
 */
/** LOB (Large Object) handling mode. */
export declare enum LobMode {
    /** No LOB support. */
    NONE = "none",
    /** All LOBs are migrated as inline data (full LOB mode). */
    FULL_LOB = "full-lob",
    /** LOBs are truncated at a configurable size. */
    LIMITED_LOB = "limited-lob"
}
/** Logging verbosity for DMS task log components. */
export declare enum LoggingLevel {
    LOGGER_SEVERITY_DEFAULT = "LOGGER_SEVERITY_DEFAULT",
    LOGGER_SEVERITY_DEBUG = "LOGGER_SEVERITY_DEBUG",
    LOGGER_SEVERITY_DETAILED_DEBUG = "LOGGER_SEVERITY_DETAILED_DEBUG",
    LOGGER_SEVERITY_ERROR = "LOGGER_SEVERITY_ERROR",
    LOGGER_SEVERITY_WARNING = "LOGGER_SEVERITY_WARNING"
}
/** Action to take on a recoverable error. */
export declare enum ErrorAction {
    /** Ignore the error and continue. */
    IGNORE = "IGNORE",
    /** Ignore the row, continue with the next. */
    IGNORE_RECORD = "IGNORE_RECORD",
    /** Stop the task. */
    STOP_TASK = "STOP_TASK"
}
/** Logging configuration for a single DMS log component. */
export interface LogComponentSettings {
    /** Logging level for this component. */
    readonly loggingLevel?: LoggingLevel;
}
/** Controls how the task handles full-load data. */
export interface FullLoadSettings {
    /**
     * Maximum number of tables to load in parallel.
     * @default 8
     */
    readonly maxFullLoadSubTasks?: number;
    /**
     * Number of rows to load before a commit.
     * @default 10000
     */
    readonly transactionConsistencyTimeout?: number;
    /**
     * Whether to create target tables if they don't exist.
     * @default true
     */
    readonly targetTablePrepMode?: string;
    /**
     * Whether to stop the task after the full load completes (only relevant for
     * full-load tasks without CDC).
     * @default false
     */
    readonly stopTaskCachedChangesApplied?: boolean;
    /** Whether DMS commits the full load in a single transaction. */
    readonly commitRate?: number;
}
/** Controls CDC behaviour. */
export interface CdcSettings {
    /**
     * Offset in seconds from current time to use as the CDC start position.
     * Ignored when `cdcStartPosition` is set on the task.
     */
    readonly enableTestMode?: boolean;
    /**
     * Whether DMS applies changes immediately (false) or batches them (true).
     * @default false
     */
    readonly batchApplyEnabled?: boolean;
    /**
     * Number of seconds DMS waits before applying batched changes.
     * Only relevant when `batchApplyEnabled` is true.
     * @default 1
     */
    readonly batchApplyTimeoutMin?: number;
    /**
     * Maximum number of seconds DMS waits before applying batched changes.
     * @default 30
     */
    readonly batchApplyTimeoutMax?: number;
    /** Memory limit (in MB) for the apply task. @default 500 */
    readonly batchApplyMemoryLimit?: number;
    /** Whether to preserve transactions during CDC. @default true */
    readonly failOnNoTablesCaptured?: boolean;
}
/** Controls error handling behaviour. */
export interface ErrorHandlingSettings {
    /**
     * Action to take when DMS encounters a data error (e.g. duplicate key).
     * @default ErrorAction.STOP_TASK
     */
    readonly dataErrorPolicy?: ErrorAction;
    /**
     * Maximum number of data errors before stopping.
     * @default 0 (unlimited)
     */
    readonly dataErrorEscalationCount?: number;
    /**
     * Action to take after `dataErrorEscalationCount` errors are hit.
     * @default ErrorAction.STOP_TASK
     */
    readonly dataErrorEscalationPolicy?: ErrorAction;
    /**
     * Action when DMS encounters a table error.
     * @default ErrorAction.STOP_TASK
     */
    readonly tableErrorPolicy?: ErrorAction;
    /**
     * Maximum number of table errors before escalation.
     * @default 0
     */
    readonly tableErrorEscalationCount?: number;
    /**
     * Action after `tableErrorEscalationCount` table errors.
     * @default ErrorAction.STOP_TASK
     */
    readonly tableErrorEscalationPolicy?: ErrorAction;
    /**
     * Whether to recover from recoverable errors.
     * @default true
     */
    readonly recoverableErrorCount?: number;
    /**
     * Interval in seconds between recovery attempts.
     * @default 5
     */
    readonly recoverableErrorInterval?: number;
    /**
     * Throttle factor applied to recovery intervals.
     * @default 2
     */
    readonly recoverableErrorThrottling?: boolean;
    /**
     * Maximum interval (seconds) between recovery attempts.
     * @default 360
     */
    readonly recoverableErrorThrottlingMax?: number;
}
/**
 * Fluent builder for DMS task settings.
 *
 * @example
 * const settings = new TaskSettings()
 *   .withLobMode(LobMode.LIMITED_LOB, 32)
 *   .withFullLoadSubTasks(16)
 *   .withBatchApply(true, 5, 60)
 *   .withDataErrorPolicy(ErrorAction.IGNORE_RECORD, 100)
 *   .withLogging('SOURCE_UNLOAD', LoggingLevel.LOGGER_SEVERITY_DEFAULT)
 *   .toJson();
 */
export declare class TaskSettings {
    private lobMode;
    private lobMaxSize;
    private fullLoadSettings;
    private cdcSettings;
    private errorHandlingSettings;
    private loggingEnabled;
    private logComponents;
    /**
     * Configure LOB handling.
     *
     * @param mode       How LOBs are handled.
     * @param maxSizeKb  Maximum LOB size in KB when mode is LIMITED_LOB. Ignored otherwise.
     */
    withLobMode(mode: LobMode, maxSizeKb?: number): TaskSettings;
    /**
     * Set the maximum number of tables loaded in parallel.
     * @param count Default 8.
     */
    withFullLoadSubTasks(count: number): TaskSettings;
    /**
     * Set the full-load target table prepare mode.
     * Common values: "DROP_AND_CREATE", "TRUNCATE_BEFORE_LOAD", "DO_NOTHING".
     */
    withTargetTablePrepMode(mode: string): TaskSettings;
    /**
     * Set the commit rate (number of rows per commit) during full load.
     */
    withCommitRate(rows: number): TaskSettings;
    /**
     * Enable or disable CDC batch apply mode and configure its timeouts.
     *
     * @param enabled    Whether batch apply is on.
     * @param minSeconds Minimum seconds before applying a batch (default 1).
     * @param maxSeconds Maximum seconds before applying a batch (default 30).
     */
    withBatchApply(enabled: boolean, minSeconds?: number, maxSeconds?: number): TaskSettings;
    /**
     * Configure the action taken on data errors.
     *
     * @param policy         Action when a data error is encountered.
     * @param escalationCount After this many errors, apply the escalation policy (0 = immediate).
     * @param escalationPolicy Action after `escalationCount` errors.
     */
    withDataErrorPolicy(policy: ErrorAction, escalationCount?: number, escalationPolicy?: ErrorAction): TaskSettings;
    /**
     * Configure recovery from transient errors.
     *
     * @param count    Maximum recovery attempts (-1 = unlimited).
     * @param interval Seconds between attempts.
     */
    withRecovery(count: number, interval?: number): TaskSettings;
    /**
     * Enable or disable CloudWatch logging for the task.
     * @default true
     */
    withLoggingEnabled(enabled: boolean): TaskSettings;
    /**
     * Set the logging level for a named DMS log component.
     *
     * Common component names: SOURCE_UNLOAD, TARGET_LOAD, TASK_MANAGER,
     * SOURCE_CAPTURE, TARGET_APPLY, REST_SERVER, TRANSFORMATION.
     */
    withLogging(component: string, level: LoggingLevel): TaskSettings;
    /**
     * Produce the JSON string that DMS expects for `replicationTaskSettings`.
     */
    toJson(): string;
}
