import * as cdk from 'aws-cdk-lib';
import * as dms from 'aws-cdk-lib/aws-dms';
import { Construct } from 'constructs';
import { Db2Settings, DynamoDbSettings, KafkaSettings, KinesisSettings, MongoDbSettings, MySqlSettings, NeptuneSettings, OpenSearchSettings, OracleSettings, PostgreSqlSettings, RedisSettings, RedshiftSettings, S3Settings, SapAseSettings, SqlServerSettings } from './endpoint-settings';
import { EndpointEngine, EndpointType } from './enums';
/**
 * Minimal contract for a DMS endpoint that can be used as a source or target
 * in a {@link DmsReplicationTask} or {@link DmsMigrationPipeline}.
 *
 * Use this interface when referencing an endpoint created outside of this
 * construct (e.g. by ARN). For endpoints created by this library, use the
 * concrete {@link DmsEndpoint} class directly — it exposes `cfnEndpoint`
 * for L1 escape-hatch access.
 */
export interface IDmsEndpoint {
    /** ARN of the DMS endpoint. */
    readonly endpointArn: string;
}
/** Props for {@link DmsEndpoint}. */
export interface DmsEndpointProps {
    /** Whether this is a source or target endpoint. */
    readonly endpointType: EndpointType;
    /** Database engine for this endpoint. */
    readonly engine: EndpointEngine;
    /**
     * Logical identifier of the endpoint (used as the DMS endpoint identifier).
     * Auto-generated from the construct ID if not provided.
     */
    readonly endpointIdentifier?: string;
    /** Database server hostname or IP address. */
    readonly serverName?: string;
    /** Database port. */
    readonly port?: number;
    /** Database user name. Used when not using Secrets Manager. */
    readonly username?: string;
    /**
     * Database password.
     *
     * @warning The resolved value is stored as **plaintext** in the CloudFormation
     * template and state file. For production workloads, use Secrets Manager
     * instead: set `secretsManagerSecretId` and `secretsManagerAccessRoleArn`
     * in the engine-specific settings (e.g. `mySqlSettings`, `postgreSqlSettings`)
     * and omit this property entirely.
     */
    readonly password?: cdk.SecretValue;
    /** Database name on the endpoint. */
    readonly databaseName?: string;
    /**
     * Extra connection attributes as a semicolon-separated string.
     * Refer to the DMS documentation for engine-specific attributes.
     */
    readonly extraConnectionAttributes?: string;
    /**
     * ARN of the SSL certificate authority certificate.
     * Required when sslMode is 'verify-ca' or 'verify-full'.
     */
    readonly certificateArn?: string;
    /**
     * SSL mode for the connection.
     * @default "none"
     */
    readonly sslMode?: string;
    /** Settings for MySQL or MariaDB endpoints. */
    readonly mySqlSettings?: MySqlSettings;
    /** Settings for PostgreSQL or Aurora PostgreSQL endpoints. */
    readonly postgreSqlSettings?: PostgreSqlSettings;
    /** Settings for Oracle endpoints. */
    readonly oracleSettings?: OracleSettings;
    /** Settings for Microsoft SQL Server endpoints. */
    readonly sqlServerSettings?: SqlServerSettings;
    /** Settings for SAP ASE (Sybase) endpoints. */
    readonly sapAseSettings?: SapAseSettings;
    /** Settings for IBM Db2 LUW endpoints. */
    readonly db2Settings?: Db2Settings;
    /** Settings for MongoDB or Amazon DocumentDB endpoints. */
    readonly mongoDbSettings?: MongoDbSettings;
    /** Settings for Amazon S3 endpoints. */
    readonly s3Settings?: S3Settings;
    /** Settings for Amazon DynamoDB target endpoints. */
    readonly dynamoDbSettings?: DynamoDbSettings;
    /** Settings for Amazon Redshift target endpoints. */
    readonly redshiftSettings?: RedshiftSettings;
    /** Settings for Amazon Kinesis Data Streams target endpoints. */
    readonly kinesisSettings?: KinesisSettings;
    /** Settings for Apache Kafka (and Amazon MSK) target endpoints. */
    readonly kafkaSettings?: KafkaSettings;
    /** Settings for Amazon OpenSearch Service target endpoints. */
    readonly openSearchSettings?: OpenSearchSettings;
    /** Settings for Amazon Neptune target endpoints. */
    readonly neptuneSettings?: NeptuneSettings;
    /** Settings for Amazon ElastiCache for Redis target endpoints. */
    readonly redisSettings?: RedisSettings;
    /**
     * Removal policy for the endpoint resource.
     * @default cdk.RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: cdk.RemovalPolicy;
}
/**
 * A DMS endpoint construct supporting every engine that DMS supports.
 *
 * Set `engine` to the desired {@link EndpointEngine} and supply the
 * matching `*Settings` property. All other `*Settings` properties are
 * ignored at runtime.
 *
 * @example
 * // MySQL source
 * new DmsEndpoint(this, 'Source', {
 *   endpointType: EndpointType.SOURCE,
 *   engine: EndpointEngine.MYSQL,
 *   serverName: 'mysql.example.com',
 *   port: 3306,
 *   username: 'dms_user',
 *   password: cdk.SecretValue.ssmSecure('/dms/mysql/password'),
 *   databaseName: 'mydb',
 * });
 */
export declare class DmsEndpoint extends Construct implements IDmsEndpoint {
    private static readonly TARGET_ONLY_ENGINES;
    private static readonly SOURCE_ONLY_ENGINES;
    private static validateEngineEndpointType;
    /** The underlying CloudFormation endpoint resource. */
    readonly cfnEndpoint: dms.CfnEndpoint;
    /** ARN of the DMS endpoint. */
    readonly endpointArn: string;
    constructor(scope: Construct, id: string, props: DmsEndpointProps);
    private buildMySqlSettings;
    private buildPostgreSqlSettings;
    private buildOracleSettings;
    private buildSqlServerSettings;
    private buildSapAseSettings;
    private buildDb2Settings;
    private buildMongoDbSettings;
    private buildDocDbSettings;
    private buildS3Settings;
    private buildDynamoDbSettings;
    private buildRedshiftSettings;
    private buildKinesisSettings;
    private buildKafkaSettings;
    private buildOpenSearchSettings;
    private buildNeptuneSettings;
    private buildRedisSettings;
}
