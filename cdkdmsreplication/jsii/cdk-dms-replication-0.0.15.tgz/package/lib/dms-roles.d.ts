import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
/**
 * Returns the account-level `dms-vpc-role` IAM role, creating it once per stack.
 * DMS requires this exact role name before it can place replication instances or
 * serverless configs inside a VPC.
 */
export declare function ensureDmsVpcRole(stack: cdk.Stack): iam.Role;
/**
 * Returns the account-level `dms-cloudwatch-logs-role` IAM role, creating it
 * once per stack. DMS requires this exact role name to publish task logs to
 * CloudWatch Logs.
 */
export declare function ensureDmsCloudWatchRole(stack: cdk.Stack): iam.Role;
